/*
 * header for the selection of cephes routines here.
 *
 * used for the bessel functions - some of the rest could be removed.
 *
 * AJJ 2013-04-05
 */

#include "mconf.h"
#include "protos.h"
